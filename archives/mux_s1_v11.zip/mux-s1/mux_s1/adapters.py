"""Readers that put data into the canonical form of `mux_s1.realdata`.

This file sits OUTSIDE the frozen set of version 1.1 on purpose: the layout of the DANDI files of
Hesse et al. becomes visible only on release day, while the statistics in `realdata.py` do not
depend on it. What an adapter must return is fixed here and in the pre-registration; the body of
`dandi_sessions` is written when the files are in hand, and the change is entered in the deviation
log together with the hash of this file at that moment.

`synthetic_sessions` builds the same canonical form from the simulator of version 1.0 and is what
the verification code is tested on before the release.
"""
import numpy as np

from . import core as C
from .realdata import Pair, Session

CALIBRATION = dict(kappa=0.13915092914337512,
                   timescale={"M0_markov": 114.0, "M1_rhythm": 157.36363636363637,
                              "M1b_rhythm_k3": 158.88888888888889, "M2_cont_unimodal": 97.10526315789474,
                              "M3_cont_bimodal": 73.33333333333333, "M4_adaptation": 114.0,
                              "M4c_adaptation_tuning": 114.0, "M5_conscious_gain": 114.0,
                              "M6_heterogeneous": 114.0, "M7_ring": 113.21038251366122,
                              "C1_averaging": 114.0, "C2_uncoordinated": 114.0})


def synthetic_sessions(model, seed=0, n_sess=19, n_pairs=25, n_tr=15, N=300, t_prime_ms=1000.0,
                       kappa=None, timescale=None, with_faces=False):
    """Canonical sessions from the MUX-S1 1.0 simulator (the DYN design of part II).

    with_faces=True also returns the 50-dimensional feature vectors of the faces of each pair, so
    the gain block can run; the DYN design has too few faces for the reconstruction analyses.
    """
    spec = C.MODELS[model]
    kappa = CALIBRATION["kappa"] if kappa is None else kappa
    timescale = CALIBRATION["timescale"][model] if timescale is None else timescale
    rng = np.random.default_rng([int(seed), 11, 1])
    out = []
    for si in range(n_sess):
        pop = C.Population(rng, N, kappa)
        F = C.make_faces(rng, 2 * n_pairs)
        D = pop.delta(F)
        pairs = []
        for j in range(n_pairs):
            a, b = 2 * j, 2 * j + 1
            ring_u = None
            if spec["kind"] == "ring":
                u = rng.standard_normal(N)
                ring_u = u / np.linalg.norm(u) * np.linalg.norm(D[a] - D[b]) / 2
            prime_a = C.poisson(rng, C.priming_rates(spec, pop, D[a], n_tr))
            prime_b = C.poisson(rng, C.priming_rates(spec, pop, D[b], n_tr))
            lam0, _ = C.binocular_rates(rng, spec, pop, D[a], D[b], n_tr, timescale, t_prime_ms, ring_u)
            lam1, _ = C.binocular_rates(rng, spec, pop, D[b], D[a], n_tr, timescale, t_prime_ms, ring_u)
            pairs.append(Pair(bino_a=C.poisson(rng, lam0), bino_b=C.poisson(rng, lam1),
                              prime_a=prime_a, prime_b=prime_b, face_a=a, face_b=b))
        out.append(Session(pairs=pairs, bin_ms=C.DT * 1000.0, name=f"{model}_s{si}",
                           faces=(F if with_faces else None),
                           meta=dict(model=model, seed=seed, kappa=kappa, timescale=timescale)))
    return out


def dandi_sessions(path, design="FACE1500", bin_ms=10.0, window_ms=(300, 1000)):
    """Reader of the released files (written on release day).

    Contract, fixed before the release:
      - returns a list of `realdata.Session`, one per recording session (the same neurons);
      - counts are binned at `bin_ms` inside `window_ms` after the onset of the flashed face for
        binocular trials, and after the onset of the primed face for priming trials;
      - `Pair.bino_a` holds the trials where face a was flashed (conscious = a), `bino_b` the
        trials where face b was; `prime_a`, `prime_b` the priming trials of each face alone;
      - `unamb_a`, `unamb_b` hold the unambiguous-context trials of the first experiment, or None;
      - `Session.faces` holds the feature vectors of the stimuli when the release provides them,
        with `face_a`, `face_b` indexing into it; otherwise None and the gain block is skipped;
      - units are spike counts per bin, integer, non-negative; no smoothing, no normalization.
    """
    raise NotImplementedError(
        "Written on release day (Hesse et al., announced for 26 Oct 2026). The contract above is "
        "part of the pre-registration; the body is logged as a deviation with its own hash.")
