# MUX-S1: what do the data of Hesse et al. (2026) draw?

A pre-registered simulation study of the population dynamics behind the rapid alternation of
"conscious" and "suppressed" micro-epochs reported by Hesse, Lanfranchi, McGrory, Shi, Engel and Tsao
(bioRxiv 10.64898/2026.10.15.759299, 16 Oct 2026) in macaque face patches during binocular flash
suppression.

The authors' data will be released on DANDI upon publication. Until then MUX-S1 asks which latent
dynamics and which mechanisms of the conscious/suppressed asymmetry are consistent with the published
fingerprint, and which yet-unpublished statistics would tell them apart.

## What is simulated

Synthetic face-cell populations (linear axis tuning in a 50-feature face space, Poisson spikes in
10-ms bins) are driven by a latent weight m(t) of the conscious face. Candidate shapes and mechanisms:

| Model | Latent dynamics / mechanism |
|---|---|
| M0 | two-state Markov switching (the authors' model) |
| M1, M1b | rhythmic switching, gamma-distributed dwell times (k = 6, k = 3) |
| M2 | continuous unimodal mixing (logit Ornstein-Uhlenbeck, SD 1.0) |
| M3 | continuous bimodal mixing (logit Ornstein-Uhlenbeck, SD 2.5) |
| M4, M4c | M0 plus stimulus adaptation of the whole drive / of the tuning part only |
| M5 | M0 plus a 1.21x tuning gain of the conscious face |
| M6 | M0 with 20% of trials where the flash fails |
| M7 | a ring: C -> X -> S -> Y -> C through two different intermediate patterns |
| C1, C2 | the authors' controls: averaging and uncoordinated switching |

The authors' analysis pipeline is reimplemented (templates from priming, Poisson LLR, fixed-emission
HMM with Baum-Welch transitions and Viterbi paths, PCA + OLS face reconstruction with leave-one-face-out
weights, modulation indices, tuning gain, order-concatenation state decoder, held-out likelihood test)
together with new discriminating statistics: a held-out likelihood test of continuous vs discrete latent
dynamics, a noise-free fourth cumulant from four disjoint neuron quarters, dwell-time CV, trial
overdispersion, an ACF rebound statistic and an exploratory loop detector.

## Main results (synthetic data; details in `MUX-S1_report.md`)

- The authors' controls (averaging, uncoordinated switching) fail 3 of the 4 tests of their battery, as in the paper; circular reconstruction is passed by every model.
- The held-out likelihood test (Extended Data Fig. 10f) rejects continuous mixing, unimodal and bimodal, at every signal strength tested. With hard state labels from half of the neurons it acts as a threshold test: two rates beat the best static mixture only when the labels are right in more than about 75% of bins.
- The sign of the Fig. 3a test (two-template mixture against a static rate from the other half of the trials) is won by every model, including models without switching, because the two sides carry unequal estimation noise.
- The shape of the published LLR autocorrelation matches Markov switching (scaled by about 1.6) and rules out strong rhythmicity among the tested models. If the per-trial mean is subtracted, as the published shuffled curve suggests, D = 67 ms corresponds to a mean dwell of about 114 ms (about 9 switches per second), whereas the published HMM median dwell (about 62 ms) corresponds to about 16 switches per second.
- A tuning-gain ratio of about 1.2 is produced by plain stimulus adaptation; no tested model reproduces it together with the higher mean rate in the suppressed state that the authors report.
- Pre-registered verdicts: H2, H3, H5 and H7 confirmed; H1, H4 and H6 not confirmed. Three discriminating statistics (D1, D2, D5) had design flaws; corrected versions are reported as exploratory analyses (E4, E5).

## Exploratory analyses added after the pre-registered runs (descriptive only)

- E3 `explore_snr.py`: the battery likelihood test and the published consistency numbers as a function of the tuning strength kappa
- E3b `explore_accuracy.py`: accuracy of the inferred state labels against the true latent state
- E4 `explore_k4.py`: a scale-corrected fourth cumulant (D2)
- E5 `explore_disc.py`: why D1 favours continuous dynamics for pure jumps, and a fairer discrete model with fitted levels

## Files

- `MUX-S1_prereg.md` (Russian) – pre-registration, SHA-256 in `MUX-S1_prereg.sha256`, code hashes in `MUX-S1_prereg_manifest.txt`
- `MUX-S1_deviations.md` – deviation log
- `MUX-S1_report.md` (Russian) – report
- `digitize/` – digitization of Figs. 2c, 2d and 5c of the preprint (`targets.json`); the preprint PDF itself (CC BY 4.0) is not included: download it from bioRxiv (DOI above) to `digitize/hesse2026.pdf` to rerun the digitization
- `mux_s1/` – model, experiments, analyses, tests
- `results/` – calibration, per-dataset results (`partI/`, `partII/`) and `summary.json`
- `figures/` – figures

## Reproduce

```bash
pip install numpy scipy scikit-learn matplotlib
python -m mux_s1.tests        # unit and invariant tests
python calibrate.py           # pre-registered calibration -> results/calibration.json
python run_parts.py I         # part I: the authors' test battery and the gain asymmetry
python run_parts.py II        # part II: discriminating statistics
python explore_snr.py         # E3 (post hoc, exploratory)
python analyze.py             # hypotheses H1-H7 -> results/summary.json
python analyze_explore.py      # E3 summary
python explore_accuracy.py; python explore_k4.py; python explore_disc.py   # E3b, E4, E5
python figures.py             # figures/*.png
```

Code: MIT. Text, figures and data: CC BY 4.0. Authors: Julia Ryzhkova (ORCID 0009-0005-4194-6059) and
Claude (Anthropic, Opus 5.5).
